"""Live web search (Tavily) + weather (Open-Meteo). The network is always mocked.

Boundaries: 8 (safety runs first and never searches), 5/6 (no medical or dose lookups), 14 (never claim an answer we
did not get: any failure is the fixed "no information" line), 12 (the Tavily key is never logged).
"""

import json
import logging
import os
import statistics
import time
from datetime import datetime
from pathlib import Path

import httpx
import pytest
from reasoning_svc import replies as rp
from reasoning_svc.core_client import CoreClient
from reasoning_svc.evon import EvonClient, load_intent_schema
from reasoning_svc.tools import weather, web_search
from reasoning_svc.turn import TurnEngine

NOW = datetime(2026, 10, 6, 9, 0)
KEY = "tavily-test-key-123456"
EVAL = Path(__file__).resolve().parents[3] / "eval" / "web_eval.jsonl"


@pytest.fixture(autouse=True)
def _clean(monkeypatch):
    web_search.reset()
    monkeypatch.setenv("TAVILY_API_KEY", KEY)
    yield
    web_search.reset()


def tavily_body(n=4):
    return {"results": [
        {"title": f"T{i} <strong>x</strong>", "content": f"snippet &amp; {i} <b>bold</b>", "url": f"https://e.test/{i}"}
        for i in range(n)
    ]}


class Clock:
    def __init__(self):
        self.t = 100.0
        self.slept = []

    def __call__(self):
        return self.t

    def sleep(self, s):
        self.slept.append(s)
        self.t += s


def client(handler):
    return httpx.Client(transport=httpx.MockTransport(handler))


# ---- the tool ---------------------------------------------------------------------------------------
def test_success_returns_top_three_cleaned_and_posts_the_documented_request():
    seen = []

    def h(req):
        seen.append(req)
        return httpx.Response(200, json=tavily_body())

    c = Clock()
    out = web_search.search("पुणे बातम्या", "mr", client=client(h), clock=c, sleep=c.sleep)
    assert out == [{"title": f"T{i} x", "snippet": f"snippet & {i} bold", "source_domain": "e.test"} for i in range(3)]
    req = seen[0]
    assert req.method == "POST" and str(req.url) == "https://api.tavily.com/search"
    assert req.headers["authorization"] == f"Bearer {KEY}"
    assert json.loads(req.content) == {
        "query": "पुणे बातम्या", "max_results": 3, "search_depth": "basic", "include_answer": False, "topic": "general",
    }


def test_second_identical_query_is_served_from_cache_for_ten_minutes():
    n = []

    def h(req):
        n.append(1)
        return httpx.Response(200, json=tavily_body())

    c = Clock()
    http = client(h)
    web_search.search("score", "en", client=http, clock=c, sleep=c.sleep)
    c.t += 599
    assert web_search.search("score", "en", client=http, clock=c, sleep=c.sleep) is not None
    assert len(n) == 1
    c.t += 5
    web_search.search("score", "en", client=http, clock=c, sleep=c.sleep)
    assert len(n) == 2


def test_timeout_is_retried_once_then_none():
    n = []

    def h(req):
        n.append(1)
        raise httpx.ReadTimeout("slow")

    c = Clock()
    assert web_search.search("q", "mr", client=client(h), clock=c, sleep=c.sleep) is None
    assert len(n) == 2


def test_429_then_200_succeeds_on_the_retry():
    codes = iter([429, 200])

    def h(req):
        code = next(codes)
        return httpx.Response(code, json=tavily_body() if code == 200 else {})

    c = Clock()
    assert web_search.search("q", "mr", client=client(h), clock=c, sleep=c.sleep) is not None


def test_no_key_returns_none_without_any_request(monkeypatch):
    monkeypatch.delenv("TAVILY_API_KEY")

    def h(req):
        raise AssertionError("no request without a key")

    assert web_search.search("q", "mr", client=client(h)) is None
    assert web_search.available() is False


@pytest.mark.parametrize("status", [401, 403, 422])
def test_client_errors_are_none_and_not_retried(status):
    n = []

    def h(req):
        n.append(1)
        return httpx.Response(status, json={})

    c = Clock()
    assert web_search.search("q", "mr", client=client(h), clock=c, sleep=c.sleep) is None
    assert len(n) == 1


def test_rate_limit_spaces_distinct_queries_one_second_apart():
    def h(req):
        return httpx.Response(200, json=tavily_body())

    c = Clock()
    http = client(h)
    web_search.search("one", "mr", client=http, clock=c, sleep=c.sleep)
    web_search.search("two", "mr", client=http, clock=c, sleep=c.sleep)
    assert c.slept and c.slept[0] == pytest.approx(1.0)


def test_rate_limit_that_cannot_fit_the_budget_is_none_without_a_request():
    n = []

    def h(req):
        n.append(1)
        return httpx.Response(200, json=tavily_body())

    c = Clock()
    http = client(h)
    web_search.search("one", "mr", client=http, clock=c, sleep=c.sleep)
    assert web_search.search("two", "mr", client=http, clock=c, sleep=c.sleep, timeout_s=0.5) is None
    assert len(n) == 1


def test_the_key_is_never_logged(caplog):
    caplog.set_level(logging.DEBUG)

    def h(req):
        return httpx.Response(500)

    c = Clock()
    web_search.search("q", "mr", client=client(h), clock=c, sleep=c.sleep)
    assert KEY not in caplog.text


def test_weather_sentence_from_open_meteo():
    def h(req):
        if "geocoding" in str(req.url):
            return httpx.Response(200, json={"results": [{"latitude": 18.5, "longitude": 73.8}]})
        return httpx.Response(200, json={
            "current": {"temperature_2m": 27.4, "weather_code": 3},
            "daily": {"temperature_2m_max": [31.2], "temperature_2m_min": [22.1], "precipitation_probability_max": [40]},
        })

    out = weather.current_weather("Pune", "mr", client=client(h))
    assert out == "Puneमध्ये आत्ता ढगाळ आहे, तापमान 27 अंश. आज 22 ते 31 अंश, पावसाची शक्यता 40 टक्के."
    assert weather.current_weather("Pune", "mr", client=client(lambda r: httpx.Response(500))) is None


# ---- the engine --------------------------------------------------------------------------------------
def _understand(case_or_none=None, *, web=True, query="q", intent="chat"):
    return {
        "intent": intent,
        "slots": {"task": None, "date": None, "time": None, "time_ambiguous": False, "query": None, "media_kind": None,
                  "media_specific": False, "control": None, "contact": None, "confirm": None, "choice": None,
                  "checkin_answer": None, "bp": None},
        "reply": "" if web else "छान.",
        "confidence": 0.9,
        "needs_web": web,
        "web_query": query if web else None,
    }


class Llm:
    def __init__(self, payload, answer="संसदेत चर्चा सुरू आहे."):
        self.payload, self.answer, self.calls = payload, answer, []

    def __call__(self, req):
        body = json.loads(req.content)
        system = body["messages"][0]["content"]
        self.calls.append((system, body["messages"][-1]["content"]))

        def r(c):
            return httpx.Response(200, json={"choices": [{"message": {"content": c}}]})

        if "Return ONLY one JSON object" in system:
            return r(json.dumps(self.payload))
        if "SEARCH RESULTS" in system:
            return r(self.answer)
        return r("ठीक आहे.")

    @property
    def web_calls(self):
        return [c for c in self.calls if "SEARCH RESULTS" in c[0]]


def make(core_http, llm):
    http = httpx.Client(transport=httpx.MockTransport(llm))
    evon = EvonClient("https://llm.test/v1", "m", http=http, schema=load_intent_schema(), provider="T")
    return TurnEngine(CoreClient(core_http), evon, clock=lambda: NOW)


@pytest.fixture()
def tavily(monkeypatch):
    calls = []

    def fake(query, lang="mr", **kw):
        calls.append((query, lang))
        return [{"title": "बातमी", "snippet": "संसदेत चर्चा सुरू आहे. " + "सविस्तर बातमी येथे वाचा आणि पुढील माहिती पहा. " * 3}]

    monkeypatch.setattr(web_search, "search", fake)
    return calls


def test_needs_web_searches_speaks_a_filler_and_answers_from_snippets(core_http, uid, tavily):
    llm = Llm(_understand(query="भारत सामना निकाल"), answer="संसदेत चर्चा सुरू आहे. https://x.test **ठीक**")
    res = make(core_http, llm).handle(uid, "काल भारताचा सामना कोण जिंकला")
    assert tavily == [("भारत सामना निकाल", "mr")]
    assert res.filler == "बघतो…"
    assert res.reply == "संसदेत चर्चा सुरू आहे. ठीक" and "http" not in res.reply and "*" not in res.reply
    assert res.intent == "CHAT" and res.source == "llm" and res.trace["web"] == "search"
    system, _ = llm.web_calls[0]
    assert "AT MOST TWO" in system and "संसदेत चर्चा सुरू आहे." in system and "https://e.test" not in system


@pytest.mark.parametrize("text", ["मला छातीत दुखतंय", "mala jagaychi iccha nahi"])
def test_safety_runs_first_and_never_searches(core_http, uid, tavily, text):
    llm = Llm(_understand())
    res = make(core_http, llm).handle(uid, text)
    assert res.mode == "safety" and tavily == [] and llm.calls == []


@pytest.mark.parametrize("text", ["बीपीची गोळी दोन घेऊ का", "शुगर वाढली तर काय करायचं", "can I double my dose today"])
def test_medicine_and_health_words_never_search(core_http, uid, tavily, text):
    llm = Llm(_understand())
    res = make(core_http, llm).handle(uid, text)
    assert tavily == [] and llm.web_calls == []
    assert res.reply != "" and "doctor" in res.reply.lower() or "डॉक्टर" in res.reply


def test_search_failure_gives_the_fixed_line(core_http, uid, monkeypatch):
    monkeypatch.setattr(web_search, "search", lambda *a, **k: None)
    res = make(core_http, Llm(_understand())).handle(uid, "आजचा सामना कोण जिंकला")
    assert res.reply == rp.R["mr"]["web_none"] == "आत्ता माहिती मिळाली नाही." and res.source == "rules"


def test_missing_key_gives_the_fixed_line_without_a_request(core_http, uid, monkeypatch):
    monkeypatch.delenv("TAVILY_API_KEY")
    res = make(core_http, Llm(_understand())).handle(uid, "आजचा सामना कोण जिंकला")
    assert res.reply == "आत्ता माहिती मिळाली नाही."


def test_llm_answer_failure_gives_the_fixed_line(core_http, uid, tavily):
    res = make(core_http, Llm(_understand(), answer="")).handle(uid, "आजचा सामना कोण जिंकला")
    assert res.reply.startswith("मला याची पक्की खात्री नाही") and res.trace["web"] == "search_unsure"  # honest, with what was found


def test_weather_uses_open_meteo_and_the_elders_city(core_http, uid, tavily, monkeypatch):
    monkeypatch.setenv("ARJUN_CITY", "Pune")
    got = []
    monkeypatch.setattr(weather, "current_weather", lambda city, lang="mr", **k: got.append(city) or "ढगाळ आहे.")
    res = make(core_http, Llm(_understand())).handle(uid, "आज पाऊस पडेल का")
    assert got == ["Pune"] and tavily == [] and res.reply == "ढगाळ आहे." and res.trace["web"] == "weather"


def test_weather_without_a_city_asks_instead_of_guessing(core_http, uid, tavily, monkeypatch):
    monkeypatch.delenv("ARJUN_CITY", raising=False)
    monkeypatch.setattr(weather, "current_weather", lambda *a, **k: pytest.fail("no city, no lookup"))
    res = make(core_http, Llm(_understand())).handle(uid, "आज पाऊस पडेल का")
    assert res.reply == rp.R["mr"]["web_city"] and tavily == []


# ---- the eval set ------------------------------------------------------------------------------------
def _cases():
    return [json.loads(line) for line in EVAL.read_text(encoding="utf-8").splitlines() if line.strip()]


def test_eval_set_has_at_least_fifteen_turns():
    assert len(_cases()) >= 15


def test_web_eval_routing_latency_and_samples(core_http, uid, monkeypatch):
    """System result: every eval turn routes as expected with a mocked Tavily/Open-Meteo/LLM. News turns go through the
    REAL web_search code (mock HTTP), so the domain filter and the spoken source are exercised, not faked. The
    latencies are the in-process cost only (network mocked at zero delay); they say nothing about real Tavily/LLM."""
    monkeypatch.setenv("ARJUN_CITY", "Pune")
    monkeypatch.setattr(weather, "current_weather", lambda city, lang="mr", **k: f"{city}: ढगाळ आहे.")
    real_search = web_search.search
    for label, url in (("लोकमत", "https://www.lokmat.com/rss"), ("लोकसत्ता", "https://loksatta.com/feed")):
        core_http.post(f"/users/{uid}/app-links", json={"kind": "rss", "label": label, "value": url, "allow_other_host": True})
    rows, lat = [], []
    for case in _cases():
        web_search.reset()
        raw = case.get("raw") or [
            {"title": s["title"], "content": s["snippet"], "url": "https://any.example/x"} for s in case.get("snippets") or []
        ]
        seen = {"q": [], "domains": []}

        def fake(query, lang="mr", _raw=raw, _seen=seen, **kw):
            _seen["q"].append(query)
            _seen["domains"].append(kw.get("domains"))
            http = client(lambda req: httpx.Response(200, json={"results": _raw}))
            kw.pop("client", None)
            return real_search(query, lang, client=http, sleep=lambda s: None, **kw)

        monkeypatch.setattr(web_search, "search", fake)
        if case.get("no_links"):
            for link in core_http.get(f"/users/{uid}/app-links").json():
                core_http.delete(f"/users/{uid}/app-links/{link['id']}")
        llm = Llm(_understand(web=case["web"], query=case.get("q", "")), answer=case.get("answer", ""))
        eng = make(core_http, llm)
        t = time.perf_counter()
        res = eng.handle(uid, case["text"])
        lat.append((time.perf_counter() - t) * 1000)
        how, expect, queries = res.trace.get("web"), case["expect"], seen["q"]
        shown = llm.web_calls[0][0] if llm.web_calls else ""
        ok = {
            "weather": how == "weather" and not queries,
            "search": how == "search" and 1 <= len(queries) <= 2 and res.reply == case["answer"] and res.filler,
            "search_fail": how == "search_failed" and res.reply == "आत्ता माहिती मिळाली नाही.",
            "blocked": not queries and not res.filler and bool(res.reply),
            "safety": res.mode == "safety" and not queries and not llm.calls,
            "no_web": how is None and not queries and not res.filler,
            # news: only family domains asked for, only an approved result shown to the LLM, source named aloud
            "news": how == "search_news" and seen["domains"] == [["lokmat.com", "loksatta.com"]]
            and "random-news.example" not in shown and "असत्यापित" not in shown
            and res.reply == rp.R[case["lang"]]["web_source"].format(src=case["source"], answer=case["answer"]),
            "news_none": how == "news_no_approved_result" and res.reply == "आत्ता माहिती मिळाली नाही." and not llm.web_calls,
            "news_nosource": how == "news_no_source" and not queries and not llm.web_calls,
        }[expect]
        rows.append((case["id"], expect, bool(ok), res.reply))
    bad = [r for r in rows if not r[2]]
    assert not bad, bad
    lat.sort()
    out = os.environ.get("WEB_EVAL_REPORT")
    if out:
        Path(out).write_text(json.dumps({
            "turns": len(rows), "routed_ok": sum(r[2] for r in rows), "p50_ms": round(statistics.median(lat), 1),
            "p95_ms": round(lat[min(len(lat) - 1, int(len(lat) * 0.95))], 1),
            "samples": [{"id": r[0], "reply": r[3]} for r in rows],
        }, ensure_ascii=False, indent=1), encoding="utf-8")
